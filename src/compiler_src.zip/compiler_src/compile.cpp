#include <iostream>
#include <string>

#include "parser.cpp"

std::string pref = "const puppeteer = require('puppeteer');\n\nasync function start() {\n\tconst browser = await puppeteer.launch({headless: false});\n\tconst page = await browser.newPage();\n";

std::string read_input() {
    std::string res;
    std::getline(std::cin, res, '\0');
    return res;
}

class Compiler {
public:
    void compile(Prog_AST const & program) {
        std::cout << pref;
        for(auto & st : program.code.get()->statements) {
            std::cout << "\tawait page." << st.get()->compile() << '\n';
        }
        std::cout << "//\tawait browser.close();\n};\n";
    }
};

int main() {
    std::ios_base::sync_with_stdio(false);
    auto code = read_input();
    auto AST = Parser(Tokenizer(code).tokenize()).parse();
    Compiler().compile(AST);
    return 0;
}

