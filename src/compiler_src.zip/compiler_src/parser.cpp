#include <memory>
#include <stack>
#include <string>
#include <sstream>
#include <variant>
#include <vector>
#include <map>

#include <iostream>

#include "tokenizer.hpp"
#include "util.hpp"

class Compilable { // TODO
public:
    virtual std::string compile() const = 0;
};

class Statement : public Printable, public Compilable {
public:
    virtual ~Statement() = default;
};

class Scope : public Statement {
public:
    std::vector<std::string> vars;
    std::vector<std::unique_ptr<Statement>> statements;
    Scope * parent{};
    void print(std::ostream &s, std::string const & prev) const override {
        s << prev << "Scope:\n";
        s << prev << "Variables: ";
        for(auto & v : vars) s << v << " ";
        s << '\n';
        s << prev << "Body: [\n";
        for(auto & st : statements) {
            st->print(s, prev + '\t');
            s << '\n';
        }
        s << prev << ']';
    }
    std::string compile() const override {
        std::string res;
        std::stringstream str(res);
        str << "{\n";
        for(auto & st : statements) {
            str << st.get()->compile() << '\n';
        }
        str << "}\n";
        return res;
    }
};

class Function : public Printable {
public:
    int arity;
    int priority;
    std::string name;
    Function(std::string name, int arity = 0, int priority = 0) : arity(arity), priority(priority), name(std::move(name)) {}
    virtual ~Function() = default;
    void print(std::ostream &s, std::string const & prev) const override {
        s << prev << name;
    }
};

class DefFunction : public Function {
public:
    std::vector<std::string> args;
    std::string body; // TODO
    DefFunction(std::string const & s) : Function(s) {}
    void print(std::ostream &s, std::string const & prev) const override {
        s << prev << name << '(';
        for(auto & arg : args) s << arg << ", ";
        s << ")\n";
        s << prev << "Body:\n";
        // body->print(s, prev + '\t');
        s << prev << body << '\n';
    }
};

class BinaryOperatorFunction : public Function {
public:
    BinaryOperatorFunction(OperatorToken const & operation) : Function(std::string{operation.repr()}, 2, operation.priority()) {}
};

class Expression : public Statement {

};

class LiteralExpression : public Expression, public std::variant<NumberToken, LiteralToken> {
public:
    using std::variant<NumberToken, LiteralToken>::variant;
    void print(std::ostream & s, std::string const & prev) const override {
        std::visit([&](auto const & a){s << prev << a.repr();}, static_cast<std::variant<NumberToken, LiteralToken> const &>(*this));
    }
    std::string compile() const override {
        if(has_type<NumberToken>(*this)) {
            auto it = std::get<NumberToken>(*this);
            return std::to_string(it.repr());
        } else {
            auto it = std::get<LiteralToken>(*this);
            return "'" + it.repr() + "'";
        }
    }
};

class VariableExpression : public Expression, public std::string {
public:
    using std::string::string;
    VariableExpression(std::string s) : std::string(std::move(s)) {}
    void print(std::ostream & s, std::string const & prev) const override {
        s << prev << static_cast<const std::string &>(*this);
    }
    std::string compile() const override {
        return static_cast<const std::string &>(*this);
    }
};

class FunctionCall : public Expression {
    void print(std::ostream &s, std::string const & prev) const override {
        s << prev << "name: " << function.get().name << '\n';
        s << prev << "args: (\n";
        for(auto &e : args) {
            e->print(s, prev + '\t');
            s << '\n';
        }
        s << prev << ")";
    }
public:
    std::reference_wrapper<Function const> function;
    std::vector<std::unique_ptr<Expression>> args;
    FunctionCall(Function const & function, std::vector<std::unique_ptr<Expression>> && args) : 
    function(function), args(std::move(args)) {}
    FunctionCall(Function const & function) : function(function) {}
    std::string compile() const override {
        std::string res = function.get().name + '(';
        res += args[0].get()->compile();
        for(int i=1;i<function.get().arity;++i) {
            res += ", " + args[i].get()->compile();
        }
        res += ')';
        return res;
    }
};

class Prog_AST : public Printable {
public:
    std::string name = "program";
    std::map<std::string, std::unique_ptr<Function>> functions;
    std::unique_ptr<Scope> code;
    void print(std::ostream & s, std::string const & prev) const override {
        s << prev << "### " << name << " ###\n";
        s << prev << "Functions: ";
        for(auto &[_, fun] : functions) {
            fun->print(s, "");
            s << ", ";
        }
        s << '\n';
        s << prev << "Code:\n";
        code->print(s, prev + '\t');
    }
};

class Parser : private TokenSequence {
    std::map<std::string, std::unique_ptr<Function>> functions;
    using iter = TokenSequence::iterator;
    void load_default_functions() {
        // if(!functions.empty()) return;
        for(auto & oper : OperatorToken::operators) {
            functions.emplace(std::pair{std::string{oper.repr()}, std::make_unique<BinaryOperatorFunction>(oper)});
        }
    }

    void load_normal_function() {
        {
        DefFunction fun("goto");
        fun.args = {"page_address"};
        fun.arity = 1;
        fun.priority = 4;
        functions.emplace("load", std::make_unique<DefFunction>(std::move(fun)));
        }
        {
        DefFunction fun("type");
        fun.args = {"where", "what"};
        fun.arity = 2;
        fun.priority = 4;
        functions.emplace("type", std::make_unique<DefFunction>(std::move(fun)));
        }
        {
        DefFunction fun("keyboard.press");
        fun.args = {"what"};
        fun.arity = 1;
        fun.priority = 4;
        functions.emplace("click", std::make_unique<DefFunction>(std::move(fun)));
        }
    }

    bool parse_end(iter & it) {
        if(is_same(ControlToken::END, *it)) {
            ++it;
            return true;
        }
        return false;
    }

    bool parse_braces(iter &from, iter to, Scope & res) {
        if(!is_same(ControlToken::LB, *from)) return false;
        iter beg = ++from;
        long deep = 1;
        for(;from != to; ++from) {
            if(is_same(ControlToken::LB, *from)) ++deep;
            else if(is_same(ControlToken::RB, *from)) --deep;
            if(!deep) break;
        }
        if(deep) throw std::string("Braces syntax error");
        std::unique_ptr<Scope> scope = std::make_unique<Scope>();
        scope->parent = &res;
        parse_scope(beg, from, *scope);
        res.statements.emplace_back(std::move(scope));
        ++from;
        return true;
    }

    std::unique_ptr<Expression> expression_from_token(Token const & token) {
        if(auto * ptr = std::get_if<LiteralToken>(&token)) {
            return std::make_unique<LiteralExpression>(*ptr);
        } else if(auto * ptr = std::get_if<NumberToken>(&token)){
            return std::make_unique<LiteralExpression>(*ptr);
        } else if(auto * ptr = std::get_if<NameToken>(&token)) { // TODO check existing variables
            return std::make_unique<VariableExpression>(ptr->repr());
        }
        throw std::string("Expression syntax error");
    }

    std::optional<std::reference_wrapper<Function const>> get_function(std::string const & S) {
        if(auto it = functions.find(S); it != functions.end()) {
            return *it->second;
        }
        return std::nullopt;
    }

    bool parse_args(iter & from, iter to, unsigned arity, std::vector<std::unique_ptr<Expression>> & res) {
        if(!is_same(ControlToken::LO, *from)) throw std::string("Error parse args");
        ++from;
        for(unsigned i=1;i<arity;++i) {
            parse_expression(from, to, res, ControlToken::COMMA);
            ++from;
        }
        parse_expression(from, to, res, ControlToken::RO);
        return true;
    }

    template<typename T, typename S = typename std::enable_if_t<std::is_base_of_v<T, Expression>>>
    bool parse_expression(iter & from, iter to, std::vector<std::unique_ptr<T>> & res, ControlToken const & end_token = ControlToken::END) {
        std::cerr << "expression\n";
        std::vector<std::variant<std::unique_ptr<Expression>, std::reference_wrapper<Function const>>> rpn;
        std::vector<std::reference_wrapper<Function const>> funs;
        auto it = from;
        auto const insert_function = [&funs, &rpn](Function const & fun) {
            while(!funs.empty() && funs.back().get().priority > fun.priority) {
                rpn.emplace_back(funs.back());
                funs.pop_back();
            }
            funs.emplace_back(fun);
        };
        for(;it != to && !is_same(ControlToken::END, *it) && !is_same(end_token, *it); ++it) { // building reverse polish notation
            std::cerr << *it << '\n';
            if(has_type<OperatorToken>(*it)) {
                auto const & fun = get_function(std::get<OperatorToken>(*it).repr()).value().get();
                insert_function(fun);
            } else if(has_type<NameToken>(*it)) {
                auto const & name_token = std::get<NameToken>(*it);
                if(auto maybe_fun = get_function(name_token)) {
                    auto const & fun = maybe_fun.value().get();
                    std::cerr << "Function "<< fun << '\n';
                    auto fun_call = std::make_unique<FunctionCall>(fun);
                    parse_args(++it, to, fun.arity, fun_call->args);
                    rpn.emplace_back(std::move(fun_call));
                } else {
                    rpn.emplace_back(std::move(expression_from_token(*it)));
                }
            } else if(has_type<LiteralToken>(*it) || has_type<NumberToken>(*it)) {
                rpn.emplace_back(std::move(expression_from_token(*it)));
            } else {
                throw std::string("Expression syntax error");
            }
        }
        while(!funs.empty()) {
            rpn.emplace_back(funs.back());
            funs.pop_back();
        }
        std::vector<std::unique_ptr<Expression>> st;
        for(auto & item : rpn) {
            if(has_type<std::unique_ptr<Expression>>(item)) {
                std::cerr << *std::get<std::unique_ptr<Expression>>(item) << " now\n";
                std::cerr << "here\n";
                st.emplace_back(std::move(std::get<std::unique_ptr<Expression>>(item)));
            } else {
                std::cerr << std::get<std::reference_wrapper<Function const>>(item).get() << " now " << st.size() << '\n';
                const auto & fun = std::get<std::reference_wrapper<Function const>>(item).get();
                const unsigned arity = fun.arity;
                if(arity > st.size()) throw std::string("Syntax args error");
                std::vector<std::unique_ptr<Expression>> args;
                args.reserve(arity);
                for_each(st.end()-arity, st.end(), [&args](auto & x){args.emplace_back(std::move(x));});
                st.resize(st.size()-arity);
                st.emplace_back(std::make_unique<FunctionCall>(fun, std::move(args)));
            }
        }
        std::cerr << "AFTER: " << st.size() << '\n';
        for(auto & x : st) std::cerr << *x << '\n';
        if(st.size() != 1) throw std::string("Syntax expression error");
        std::unique_ptr<Expression> expr = std::move(st.front());
        res.emplace_back(std::move(expr));
        from = it;
        return true;
    }

    bool parse_control(iter & from, iter to, Scope & res) {
        return false;
    }

    bool parse_scope(iter from, iter to, Scope & res) {
        while(from != to) {
            if(parse_end(from) || parse_braces(from, to, res) || parse_expression(from, to, res.statements) || parse_control(from, to, res)) continue;
            return false;
        }
        return true;
    }
public:
    Parser(TokenSequence && seq) : TokenSequence(std::move(seq)) {
        std::cerr << static_cast<TokenSequence&>(*this) << '\n';
        load_default_functions();
        load_normal_function();
    }
    Prog_AST parse() {
        Prog_AST result;
        result.code = std::make_unique<Scope>();
        if(!parse_scope(begin(), end(), *result.code)) throw std::string("Syntax error");
        result.functions = std::move(functions);
        return result;
    }
};

// int main() {
//     using namespace std;
//     // string s = "F(a+b*c,g,h) * a - F(a,a,a) * j";
//     string s = "load(\"https://developers.google.com/web/\")\ntype(\".devsite-search-field\", \"Headless Chrome\")\nclick(\"Enter\")\n";
//     Parser parser(Tokenizer(s).tokenize());
//     cout << parser.parse() << '\n';
//     return 0;
// }